import { HeroSection } from '../components/Sections';

export default function Home() {
  return (
    <div className="min-h-screen">
      <HeroSection />
    </div>
  );
}
